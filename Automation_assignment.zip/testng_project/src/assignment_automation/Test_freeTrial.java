package assignment_automation;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

public class Test_freeTrial 
{
  WebDriver driver;
  Actions a;
  JavascriptExecutor js;
  
  @Test(priority=0)
  public void setUp() throws Exception
  {
	  System.setProperty("webdriver.chrome.driver","D:\\selenium\\chromedriver_win32 (2)\\chromedriver.exe");
		driver=new ChromeDriver();
		//To maximize screen
		driver.manage().window().maximize();
		driver.manage().deleteAllCookies();
		Thread.sleep(3000);
		//launch site
		driver.get("https://www.muvi.com/");
		Thread.sleep(3000);
		//click free trial
		driver.findElement(By.xpath("//button[normalize-space()='Free Trial']")).click();
  }
  
  @Test(priority=1)
  @Parameters({"myName","companyName"})
  public void signUp(String nm, String cn) throws InterruptedException
  {
	  driver.manage().timeouts().pageLoadTimeout(30,TimeUnit.SECONDS);
	  driver.manage().timeouts().implicitlyWait(10,TimeUnit.SECONDS);
	  //Enter details
	  driver.findElement(By.id("name")).sendKeys(nm);
      Thread.sleep(3000);
      driver.findElement(By.id("companyname")).clear();
      Thread.sleep(3000);
      driver.findElement(By.id("companyname")).sendKeys(cn);
      Thread.sleep(3000);
      driver.findElement(By.name("phone")).sendKeys("9438378902");
      Thread.sleep(3000);
      driver.findElement(By.name("email")).sendKeys("jinupsm@gmail.com");
      Thread.sleep(3000);
      driver.findElement(By.id("inputPassword")).sendKeys("muvi1234");
      Thread.sleep(3000);
      //Accept Terms and Condition
      WebElement e3=driver.findElement(By.xpath("//*[@id='accept']"));
      a=new Actions(driver);
      a.click(e3).build().perform();
      Thread.sleep(3000);
      //click next
      WebElement e2=driver.findElement(By.xpath("//button[normalize-space()='NEXT']"));
      Thread.sleep(5000);
      a.click(e2).build().perform();
  }
  
  @Test(priority=2)
  public void contentType() throws Exception
  {
	  a=new Actions(driver);
	  driver.manage().timeouts().pageLoadTimeout(30,TimeUnit.SECONDS);
	  driver.manage().timeouts().implicitlyWait(10,TimeUnit.SECONDS);
	  //Deselect subscription
	  WebElement e4=driver.findElement(By.xpath("//div[6]//div[2]//div[1]"));
      Thread.sleep(3000);
      a.click(e4).build().perform();
      Thread.sleep(3000);
      //Select Advertisement
      WebElement e5=driver.findElement(By.xpath("//div[6]//div[4]//div[1]"));
      Thread.sleep(3000);
      a.click(e5).build().perform();
      Thread.sleep(3000);
      //click save
      driver.findElement(By.id("nextbtn")).click();  
  }
  
       @Test(priority=3)
        public void tearDown() throws InterruptedException
        {  
    	   driver.manage().timeouts().pageLoadTimeout(50,TimeUnit.SECONDS);
    	    driver.manage().timeouts().implicitlyWait(20,TimeUnit.SECONDS);
    	    //close all
        	driver.quit();
        }
}
