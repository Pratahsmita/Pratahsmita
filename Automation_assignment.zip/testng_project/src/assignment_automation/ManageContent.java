package assignment_automation;

import java.awt.Robot;
import java.awt.Toolkit;
import java.awt.datatransfer.StringSelection;
import java.awt.event.KeyEvent;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

public class ManageContent 
{
	WebDriver driver;
	  Actions a;
	  JavascriptExecutor js;
	  
	  @Test(priority=0)
	  public void setUp() throws Exception
	  {
		  System.setProperty("webdriver.chrome.driver","D:\\selenium\\chromedriver_win32 (2)\\chromedriver.exe");
			driver=new ChromeDriver();
			//To maximize screen
			driver.manage().window().maximize();
			driver.manage().deleteAllCookies();
			Thread.sleep(3000);
			//launch site
			driver.get("https://www.muvi.com/");
	  }
     @Test(priority=1)
     @Parameters({"Email","Password"})
     public void login(String e, String p) throws Exception
     {
    	 driver.manage().timeouts().pageLoadTimeout(30,TimeUnit.SECONDS);
   	     driver.manage().timeouts().implicitlyWait(10,TimeUnit.SECONDS);
   	     //Enter login credentials
    	 driver.findElement(By.id("load_login")).click();
 		Thread.sleep(2000);
 		driver.findElement(By.id("LoginForm_email")).sendKeys(e);
 		Thread.sleep(2000);
 		driver.findElement(By.id("LoginForm_password")).sendKeys(p);
 		Thread.sleep(2000);
 		//click on log in
 		driver.findElement(By.id("btn-login")).click();
     }
     @Test(priority=2)
     public void createContent() throws Exception
     {
   	  a=new Actions(driver);
   	driver.manage().timeouts().pageLoadTimeout(30,TimeUnit.SECONDS);
	  driver.manage().timeouts().implicitlyWait(10,TimeUnit.SECONDS);
	  //Goto manage content
   	  WebElement e= driver.findElement(By.xpath("//a[normalize-space()='Manage Content']"));
   		Thread.sleep(5000);
   		a.moveToElement(e).build().perform();
   		Thread.sleep(2000);
   		//click content library
   		driver.findElement(By.xpath("//a[normalize-space()='Content Library']")).click();
   		Thread.sleep(3000);
   		//click add content
   		driver.findElement(By.xpath("//button[normalize-space()='Add Content']")).click();
   		Thread.sleep(3000);
   		//content name
   		driver.findElement(By.id("mname")).sendKeys("New-content");
   		Thread.sleep(2000);
   		//upload poster file
   		driver.findElement(By.id("browse-upload-poster")).click();
   		Thread.sleep(2000);
   		driver.findElement(By.xpath("//input[@onclick=\"click_browse('celeb_pic')\"]")).click();
   		Thread.sleep(2000);
   		Robot r= new Robot();
   		StringSelection poster= new StringSelection("C:\\Users\\LENOVO\\Pictures\\Saved Pictures\\Automation.png");
   		Toolkit.getDefaultToolkit().getSystemClipboard().setContents(poster,null);
   		r.keyPress(KeyEvent.VK_CONTROL);
   		r.keyPress(KeyEvent.VK_V);
   		r.keyRelease(KeyEvent.VK_V);
   		r.keyRelease(KeyEvent.VK_CONTROL);
   		Thread.sleep(3000);
   		r.keyPress(KeyEvent.VK_ENTER);
   		r.keyRelease(KeyEvent.VK_ENTER);
   		Thread.sleep(3000);
   		driver.findElement(By.xpath("//div[@id='myLargeModalLabel']//button[contains(@type,'button')][normalize-space()='Next']")).click();
   		Thread.sleep(3000);
   		//Enter release date
   		driver.findElement(By.id("release_date")).sendKeys("06172021", Keys.ENTER);
   		Thread.sleep(3000);
   		//Enter description
   		driver.findElement(By.id("story")).sendKeys("Automation Testing on content library");
   		Thread.sleep(3000);
   		//select category
   		driver.findElement(By.xpath("//option[@value='810815']")).click();
   		Thread.sleep(3000);
   		//Enter searchtags
   		driver.findElement(By.xpath("//input[@class='tt-input form-control input-sm']")).sendKeys("#test");
   		Thread.sleep(3000);
   		//To check preview link
   		driver.findElement(By.id("trailer_btn")).click();
   		Thread.sleep(2000);
   		driver.findElement(By.xpath("//div[@id='addvideo_popup']//button[@type='button'][normalize-space()='Close']")).click();
   		Thread.sleep(3000);
   		//To check error message for invalid file size upload
   		driver.findElement(By.id("add_change-top-banner-text")).click();
   		Thread.sleep(2000);
   		driver.findElement(By.xpath("//input[contains(@class,'btn btn-default-with-bg btn-file btn-sm')]")).click();
   		Thread.sleep(2000);
   		StringSelection p= new StringSelection("C:\\Users\\LENOVO\\Pictures\\Saved Pictures\\Banner_pic.jpg");
   		Toolkit.getDefaultToolkit().getSystemClipboard().setContents(p,null);
   		r.keyPress(KeyEvent.VK_CONTROL);
   		r.keyPress(KeyEvent.VK_V);
   		r.keyRelease(KeyEvent.VK_V);
   		r.keyRelease(KeyEvent.VK_CONTROL);
   		Thread.sleep(3000);
   		r.keyPress(KeyEvent.VK_ENTER);
   		r.keyRelease(KeyEvent.VK_ENTER);
   		Thread.sleep(3000);
   		driver.findElement(By.xpath("//button[normalize-space()='OK']")).click();
   		Thread.sleep(2000);
   		driver.findElement(By.xpath("//form[@id='topbannerForm']//button[@type='button'][normalize-space()='Cancel']")).click();
   		Thread.sleep(5000);
   		//click on Add new cast
   		WebElement cast=driver.findElement(By.xpath("//a[normalize-space()='Add New Cast']"));
   		js=(JavascriptExecutor)driver;
   		js.executeScript("arguments[0].click();",cast);
   		Thread.sleep(2000);
   		//Enter cast name
   		WebElement cn=driver.findElement(By.id("castname"));
   		Thread.sleep(3000);
   		a.sendKeys(cn,"Pratahsmita",Keys.DOWN,Keys.ENTER).build().perform();
   		Thread.sleep(5000);
   		//create and select cast type
   		driver.findElement(By.xpath("//button[normalize-space()='Select Cast/Crew Type']")).click();
   		Thread.sleep(2000);
   		driver.findElement(By.linkText("New Type")).click();
   		Thread.sleep(3000);
   		driver.findElement(By.id("typenew")).sendKeys("Tester");
   		Thread.sleep(2000);
   		driver.findElement(By.xpath("//em[@title='Save']")).click();
   		Thread.sleep(2000);
   		driver.findElement(By.xpath("//*[@id=\"ajaxshowtype\"]/button")).click();
   		Thread.sleep(2000);
   		driver.findElement(By.xpath("//*[text()='Tester']")).click();
   		Thread.sleep(3000);
   		//check upload profile picture link
   		driver.findElement(By.xpath("//div[@class='btn btn-default-with-bg btn-sm upload_cast_image']")).click();
   		Thread.sleep(2000);
   		driver.findElement(By.id("next")).click();
   		Thread.sleep(2000);
   		//click Add
   		driver.findElement(By.id("add_btn")).click();
   		Thread.sleep(2000);
   		//Save data
   		driver.findElement(By.id("save-btn")).click();
   		Thread.sleep(3000);
   		//Goto manage conent
   		WebElement e1= driver.findElement(By.xpath("//a[normalize-space()='Manage Content']"));
   		Thread.sleep(5000);
   		a.moveToElement(e1).build().perform();
   		Thread.sleep(2000);
   		//click on content library
   		driver.findElement(By.xpath("//a[normalize-space()='Content Library']")).click();
     }
          
           @Test(priority=3)
           public void verifyFrontendName() throws Exception
          {
           driver.manage().timeouts().pageLoadTimeout(30,TimeUnit.SECONDS);
           driver.manage().timeouts().implicitlyWait(10,TimeUnit.SECONDS);
        	//Select created data name and front-end page is loaded  	  
           	driver.findElement(By.xpath("//div[normalize-space()='New-content']")).click();
       		Thread.sleep(2000);
       		//To get title of front end page
       		String x=driver.getTitle();
       		System.out.println("page title is:"+ x);
            //To verify front end name with created content name
       			if (driver.findElement(By.xpath("//*[contains(text(),'New-content')]")).isDisplayed())
       			{
       				System.out.println("Frontend name is passed");
       			}
           else
           {
        	   System.out.println("verify name test is failed");
           }
          }
           
           @Test(priority=4)
           public void tearDown()
           {
        	driver.manage().timeouts().pageLoadTimeout(50,TimeUnit.SECONDS);
            driver.manage().timeouts().implicitlyWait(20,TimeUnit.SECONDS);
        	// close all windows    
           	driver.quit();
           }
}

